package ar.org.centro8.curso.java.aplicaciones.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/plain;charset=UTF-8");
        HttpSession session=request.getSession();
        try (PrintWriter out = response.getWriter()) {
            try {
                String user=request.getParameter("user");
                String pass=request.getParameter("pass");
                if(user.equals("root") && pass.equals("123")){
                    session.setAttribute("nombre", user);
                    session.setAttribute("session", true);
                    response.sendRedirect("welcome.jsp");
                }else{
                    session.setAttribute("session", false);
                    response.sendRedirect("logout.jsp");
                }
            } catch (Exception e) {
                response.sendRedirect("logout.jsp");
            }
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("logout.jsp");
    } 

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

// </editor-fold>

}
