package ar.org.centro8.curso.java.aplicaciones.services;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/webresources")
public class JaxRSConfig extends Application{

}