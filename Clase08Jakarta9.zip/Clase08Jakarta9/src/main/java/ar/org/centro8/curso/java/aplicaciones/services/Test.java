package ar.org.centro8.curso.java.aplicaciones.services;

import ar.org.centro8.curso.java.aplicaciones.repositories.jdbc.ArticuloRepository;
import ar.org.centro8.curso.java.connectors.Connector;
import com.google.gson.Gson;
import java.io.Serializable;
import jakarta.enterprise.context.SessionScoped;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/test")
@SessionScoped
public class Test implements Serializable{
    
    /*
        - Especificación JaxRS        
        - Libreria Jersey (cumple con JaxRS) desde javaEE 6 esta incluida
        
    */
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "<h1>Hola Mundo WS RS!</h1>";
    }
    
    @GET
    @Path("/info")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "Método info2!";
    }
 
    @GET
    @Path("/calc")
    @Produces(MediaType.TEXT_PLAIN)
    public String calculadora(@QueryParam("nro1")int numero1, @QueryParam("nro2")int numero2){
        int resultado=numero1+numero2;
        return resultado+"";
    }
    
    @GET
    @Path("/list")
    @Produces(MediaType.APPLICATION_JSON)
    public String list(){
        return new Gson().toJson(new ArticuloRepository(Connector.getConnection()).getAll());
    }
    
}