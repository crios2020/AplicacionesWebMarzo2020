package ar.org.centro8.curso.java.aplicaciones.services;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/webresources")
public class JaxRSConfig extends Application{

}