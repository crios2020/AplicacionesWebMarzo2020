package ar.org.centro8.curso.java.aplicaciones.test;

import java.time.LocalTime;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestPersistenceConnector {
    public static void main(String[] args) {
        System.out.println(LocalTime.now());
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        System.out.println(LocalTime.now());
        EntityManager em=emf.createEntityManager();
        System.out.println(LocalTime.now());
        
        em.close();
        System.out.println(LocalTime.now());
        emf.close();
        System.out.println(LocalTime.now());
    }
}
