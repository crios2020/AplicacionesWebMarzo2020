package ar.org.centro8.curso.java.aplicaciones.test;

import ar.org.centro8.curso.java.aplicaciones.entities.Articulo;
import ar.org.centro8.curso.java.aplicaciones.enums.Temporada;
import ar.org.centro8.curso.java.aplicaciones.enums.Tipo;
import java.time.LocalTime;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestPersistenceConnector {
    public static void main(String[] args) {
        System.out.println(LocalTime.now());
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        System.out.println(LocalTime.now());
        EntityManager em=emf.createEntityManager();
        System.out.println(LocalTime.now());
        Articulo articulo =new Articulo("Tapado", Tipo.ROPA, "Negro", "3", 3, 1, 5, 10000d, 20000d, Temporada.VERANO);
        //em.getTransaction().begin();
        //em.persist(articulo);
        //em.getTransaction().commit();
        //System.out.println(articulo);
        
        em
                .createNamedQuery("Articulo.findAll")
                .getResultList()
                .forEach(System.out::println);
        
        //Query query=em.createNamedQuery("Articulo.findByColor");
        //query.setParameter("color", "negro");
        //query.getResultList().forEach(System.out::println);
        
        em.close();
        System.out.println(LocalTime.now());
        emf.close();
        System.out.println(LocalTime.now());

        
        
    }
}
