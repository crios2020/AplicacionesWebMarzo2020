package clase04client;
import ar.org.centro8.curso.java.aplicaciones.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest;



import java.net.URI;
import java.util.List;
public class Clase04Client {

    public static void main(String[] args) throws Exception {
        String url="http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=Medrano%20162";
        System.out.println("****************************************************");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase05/ArticuloAlta?descripcion=Vaso_Vidrio&costo=90";
        System.out.println("****************************************************");
        System.out.println("Servicio Alta Articulos.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase05/ArticuloAlta?descripcion=Plato_Ceramica&costo=90";
        System.out.println("****************************************************");
        System.out.println("Servicio Alta Articulos.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase05/ArticuloAlta?descripcion=Cuchillo_Cocina&costo=990";
        System.out.println("****************************************************");
        System.out.println("Servicio Alta Articulos.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase05/ArticuloAll";
        System.out.println("****************************************************");
        System.out.println("Servicio ArticuloAll.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase05/ArticuloLikeDescripcion?descripcion=va";
        System.out.println("****************************************************");
        System.out.println("Servicio ArticuloLikeDescripcion.");
        System.out.println(responseBody(url));
        
        //Armar List JSon
        //Type listType=new TypeToken<List<Articulo>>(){}.getType();
        url="http://localhost:8089/Clase05/ArticuloAll";
        System.out.println("****************************************************");
        System.out.println("List<Articulo>");
        List<Articulo>list=new Gson()
                .fromJson(responseBody(url),new TypeToken<List<Articulo>>(){}.getType());
        list.forEach(System.out::println);
 
        url="http://localhost:8089/Clase05/Login";
        System.out.println("****************************************************");
        String user="root";
        String pass="123";
        System.out.println(session(url,user,pass));
        
        url="http://localhost:8089/Clase05/ArticuloBaja?id=0";
        System.out.println("****************************************************");
        System.out.println("Servicio Baja Articulos.");
        System.out.println(responseBody(url));
    }
    
    private static String session(String url, String user, String pass){
        //create the http client

        // https://mkyong.com/java/how-to-send-http-request-getpost-in-java/
        
        
        return "";
    }

    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url)).PUT(HttpRequest.BodyPublishers.ofString(""))
                .build();
        HttpResponse<String> response=client.send(request, HttpResponse.BodyHandlers.ofString());
        
        response.headers().map().forEach((k,v)->System.out.println(k+" "+v));
        return response.body();
    }

}
