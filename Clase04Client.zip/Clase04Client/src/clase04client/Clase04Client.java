package clase04client;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest;
import java.net.URI;
public class Clase04Client {

    public static void main(String[] args) throws Exception {
        String url="http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=Medrano%20162";
        System.out.println("****************************************************");
        System.out.println("Servicio de normalización de direcciones.");
        //System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase04/ArticuloAlta?descripcion=Vaso_Vidrio&costo=90";
        System.out.println("****************************************************");
        System.out.println("Servicio Alta Articulos.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase04/ArticuloAlta?descripcion=Plato_Ceramica&costo=90";
        System.out.println("****************************************************");
        System.out.println("Servicio Alta Articulos.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase04/ArticuloAll";
        System.out.println("****************************************************");
        System.out.println("Servicio ArticuloAll.");
        System.out.println(responseBody(url));
        
        url="http://localhost:8089/Clase04/ArticuloLikeDescripcion?descripcion=va";
        System.out.println("****************************************************");
        System.out.println("Servicio ArticuloLikeDescripcion.");
        System.out.println(responseBody(url));
        
        //Armar List JSon
        
    }

    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response=client.send(request, HttpResponse.BodyHandlers.ofString());
        
        response.headers().map().forEach((k,v)->System.out.println(k+" "+v));
        return response.body();
    }

}
